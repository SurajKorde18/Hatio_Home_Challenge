import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';

const ProjectList = () => {
  const [projects, setProjects] = useState([]);


  useEffect(() => {
    axios.get(`http://localhost:8080/api/projects`)
      .then(response => setProjects(response.data))
      .catch(error => console.error(error));
  }, []);
  
  return (
    <div>
      <h2>Projects</h2>
      <Link to="/create-project">Create New Project</Link>
      <ul>
        {  projects.length > 0 ? (
          projects?.map(project => (
            <li key={project.id}>
              <Link to={`/projects/${project.id}`}>{project.title}</Link>
            </li>
          ))
        ) : (
          <p>No projects found.</p>
        )}
      </ul>
    </div>
  );
};

export default ProjectList;
