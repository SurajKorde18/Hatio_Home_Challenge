import React from 'react'
import { BrowserRouter,Routes, Route } from 'react-router-dom';
import ProjectList from './components/ProjectList';
import ProjectDetails from './components/ProjectDetails';
import CreateProject from './components/CreateProject';
const App = () => {
  return (
    <BrowserRouter>
      <div className="App">
      <h1>Todo Manager</h1>
      <Routes>
        <Route path="/" element={<ProjectList/>} />
        <Route path="/projects/:id" element={<ProjectDetails />} />
        <Route path="/create-project" element={<CreateProject />} />
      </Routes>
    </div>
    </BrowserRouter>
  )
}

export default App