package com.task.Todo_App.service;

import java.time.LocalDate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.task.Todo_App.entity.Project;
import com.task.Todo_App.entity.Todo;
import com.task.Todo_App.repository.ProjectRepository;
import com.task.Todo_App.repository.TodoRepository;
import java.util.*;
@Service
public class TodoService {

	@Autowired
	private TodoRepository todoRepository;
	
	@Autowired
	private ProjectRepository projectRepository;

	

	public Todo addTodoToProject(Integer projectId, String description) {
		Todo todo = new Todo();
		todo.setDescription(description);
		todo.setCreatedDate(LocalDate.now());
		todo.setStatus(false);
		Project p1 = projectRepository.findById(projectId).orElseThrow();
		todo.setProject(p1);
		return todoRepository.save(todo);
	}

    public List<Todo> getTodosByProject(Integer projectId) {
    	Optional<Project> optionalProject = projectRepository.findById(projectId);
    	return optionalProject.get().getTodos();
    }

	public void markTodoAsComplete(Integer todoId) {
		Todo todo = todoRepository.findById(todoId).orElseThrow();
		todo.setStatus(true);
		todo.setUpdatedDate(LocalDate.now());
		todoRepository.save(todo);
	}
}
