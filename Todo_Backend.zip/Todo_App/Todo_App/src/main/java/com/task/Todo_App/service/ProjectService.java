package com.task.Todo_App.service;

import java.time.LocalDate;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.task.Todo_App.entity.Project;
import com.task.Todo_App.entity.Todo;
import com.task.Todo_App.repository.ProjectRepository;
import java.io.IOException;
import okhttp3.*;
import org.json.JSONObject;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.MediaType;


@Service
public class ProjectService {
	@Autowired
	private ProjectRepository projectRepository;
	
	public Project createProject(String title) {
        Project project = new Project();
        project.setTitle(title);
        project.setCreatedDate(LocalDate.now());
        return projectRepository.save(project);
    }

    public List<Project> getAllProjects() {
        return projectRepository.findAll();
    }

    public Project updateProjectTitle(Integer projectId, String newTitle) {
        Project project = projectRepository.findById(projectId).orElseThrow();
        project.setTitle(newTitle);
        return projectRepository.save(project);
    }

	public Project findProjectById(Integer id) {
		Project project = projectRepository.findById(id).orElseThrow();
		return project;
	}
	
	
	//---------------------------------------------------------------------------------------------------------------
	
	// Generate markdown content for the project
    private String generateMarkdownContent(Project project) {
        StringBuilder markdown = new StringBuilder();

        // Project title as a heading
        markdown.append("# ").append(project.getTitle()).append("\n\n");

        // Summary of completed vs total todos
        long completedCount = project.getTodos().stream().filter(Todo::getStatus).count();
        markdown.append("Summary: ").append(completedCount).append(" / ").append(project.getTodos().size()).append(" completed.\n\n");

        // Pending todos (unchecked boxes)
        markdown.append("## Pending Todos:\n");
        project.getTodos().stream().filter(todo -> !todo.getStatus())
            .forEach(todo -> markdown.append("- [ ] ").append(todo.getDescription()).append("\n"));

        // Completed todos (checked boxes)
        markdown.append("\n## Completed Todos:\n");
        project.getTodos().stream().filter(Todo::getStatus)
            .forEach(todo -> markdown.append("- [x] ").append(todo.getDescription()).append("\n"));

        return markdown.toString();
    }

    // Method to create a secret gist using the GitHub API
    public String exportToGist(Integer projectId) throws IOException {
        // Fetch project from database
        Project project = projectRepository.findById(projectId)
            .orElseThrow(() -> new RuntimeException("Project not found"));

        // Generate markdown content for the gist
        String markdownContent = generateMarkdownContent(project);

        // Create a secret gist on GitHub
        return createSecretGist(project.getTitle(), markdownContent);
    }

    // Helper method to create a Gist on GitHub using GitHub API
    private String createSecretGist(String title, String content) throws IOException {
        // Prepare GitHub Gist API call using OkHttp client
        OkHttpClient client = new OkHttpClient();

        // Gist filename (based on project title)
        String gistFileName = title.replaceAll("\\s+", "_") + ".md";

        // Create JSON payload for the Gist
        JSONObject fileContent = new JSONObject();
        fileContent.put("content", content);

        JSONObject files = new JSONObject();
        files.put(gistFileName, fileContent);

        JSONObject gist = new JSONObject();
        gist.put("description", "Project Gist for " + title);
        gist.put("public", false);  // Secret Gist
        gist.put("files", files);

        // Prepare HTTP POST request with GitHub API
        RequestBody body = RequestBody.create(gist.toString(), MediaType.parse("application/json"));
        Request request = new Request.Builder()
            .url("https://api.github.com/gists")
            .post(body)
            .addHeader("Authorization", "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") 
            .addHeader("Content-Type", "application/json")
            .build();

        // Execute the API call and handle the response
        Response response = client.newCall(request).execute();
        if (!response.isSuccessful()) throw new IOException("Failed to create Gist: " + response);

        // Parse response to get the Gist URL
        JSONObject responseBody = new JSONObject(response.body().string());
        return responseBody.getString("html_url");
    }
	
}
