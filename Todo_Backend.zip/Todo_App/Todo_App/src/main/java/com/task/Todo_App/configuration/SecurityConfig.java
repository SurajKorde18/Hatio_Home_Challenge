//package com.task.Todo_App.configuration;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.web.SecurityFilterChain;
//
//@Configuration
//public class SecurityConfig {
//
//    @Bean
//    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
//        http
//            .cors()  // Enable CORS globally
//            .and()
//            .csrf().disable()  // Disable CSRF for APIs if you're using JWT or session-less auth
//            .authorizeRequests()
//            .anyRequest().permitAll();  // Adjust based on your security needs
//
//        return http.build();
//    }
//}
//
