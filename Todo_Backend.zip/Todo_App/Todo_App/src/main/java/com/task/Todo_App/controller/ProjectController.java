package com.task.Todo_App.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.task.Todo_App.entity.Project;
import com.task.Todo_App.service.ProjectService;

@RestController
@RequestMapping("api/projects")
@CrossOrigin(origins = "http://localhost:5173/")
public class ProjectController {
	@Autowired
	private ProjectService projectService;

	@PostMapping
	public ResponseEntity<Project> createProject(@RequestBody Map<String, String> request) {
		Project project = projectService.createProject(request.get("title"));
		return new ResponseEntity<>(project, HttpStatus.CREATED);
	}
	 @GetMapping("/{id}")
	    public ResponseEntity<Project> getProjectById(@PathVariable Integer id) {
	        Project project = projectService.findProjectById(id);
	        return new ResponseEntity<>(project, HttpStatus.OK);
	    }

	@GetMapping
	public List<Project> getAllProjects() {
		return projectService.getAllProjects();
	}

	@PutMapping("/{id}")
	public ResponseEntity<Project> updateProjectTitle(@PathVariable Integer id,
			@RequestBody Map<String, String> request) {
		Project updatedProject = projectService.updateProjectTitle(id, request.get("title"));
		return new ResponseEntity<>(updatedProject, HttpStatus.OK);
	}
	
	//------------------------------------------------------------------------------------------------------
	
	// Endpoint to export project to Gist
    @PostMapping("/{projectId}/export-gist")
    public String exportProjectToGist(@PathVariable Integer projectId) {
        try {
            // Call service method to export to Gist
            return projectService.exportToGist(projectId);
        } catch (IOException e) {
            return "Error exporting to Gist: " + e.getMessage();
        }
    }
}
